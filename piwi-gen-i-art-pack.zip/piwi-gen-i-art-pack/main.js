Hooks.once("ready", async () => {
    // 1. Fetch your custom item mapping data file
    let artMapping;
    try {
        const response = await fetch("modules/piwi-gen-i-art-pack/item-mapping.json");
        if (!response.ok) return;
        artMapping = await response.json();
    } catch (err) {
        console.error("PIWI Art Pack | Error reading item-mapping.json:", err);
        return;
    }

    // Enhanced loose match utility that strips out parentheses and weird punctuation
    const getArtworkMatch = (entry, itemData) => {
        if (!entry) return null;
        if (itemData[entry._id] || itemData[entry.id]) return itemData[entry._id] || itemData[entry.id];
        
        // Helper function to turn any string into a clean, uniform slug
        const cleanToSlug = (str) => {
            return str
                ?.toLowerCase()
                .replace(/[^a-z0-9]+/g, "-") // Turn spaces/punctuation into hyphens
                .replace(/(^-|-$)/g, "")     // Strip leading/trailing hyphens
                .replace(/-+/g, "-");        // Collapse multiple hyphens (---) into one (-)
        };

        // 1. Direct match on system slug vs JSON key
        if (entry.slug && itemData[entry.slug]) return itemData[entry.slug];

        // 2. Loose match: Clean the entry's slug or name and compare to cleaned JSON keys
        const entrySlug = entry.slug ? cleanToSlug(entry.slug) : cleanToSlug(entry.name);
        
        for (const [key, value] of Object.entries(itemData)) {
            if (cleanToSlug(key) === entrySlug) {
                return value;
            }
        }
        
        return null;
    };

    // 2. Map and Intercept Database Collections
    for (const [packId, itemData] of Object.entries(artMapping)) {
        const pack = game.packs.get(packId);
        if (!pack) continue;

        // Overwrite Sidebar Directory Reference Index
        const originalGetIndex = pack.getIndex.bind(pack);
        pack.getIndex = async function(options) {
            const index = await originalGetIndex(options);
            for (const entry of index) {
                const match = getArtworkMatch(entry, itemData);
                if (match?.img) entry.img = match.img;
            }
            return index;
        };

        // Overwrite Raw Loaded Documents (Retains image when items are viewed)
        const originalGetDocuments = pack.getDocuments.bind(pack);
        pack.getDocuments = async function(query, options) {
            const docs = await originalGetDocuments(query, options);
            for (const doc of docs) {
                const match = getArtworkMatch(doc, itemData);
                if (match?.img) doc.updateSource({ img: match.img });
            }
            return docs;
        };

        // Overwrite Single Drag-and-Drop Resolution Trait
        const originalGetDocument = pack.getDocument.bind(pack);
        pack.getDocument = async function(id, options) {
            const doc = await originalGetDocument(id, options);
            if (doc) {
                const match = getArtworkMatch(doc, itemData);
                if (match?.img) doc.updateSource({ img: match.img });
            }
            return doc;
        };

        // CRITICAL FIX: Force the standard sidebar directory to visually rebuild its HTML structure
        pack.getIndex().then(() => {
            if (ui.compendium.rendered) ui.compendium.render(true);
        });
    }

    // 3. Complete PF2e Compendium Browser Interception Hook
    Hooks.on("pf2e.compendiumBrowserInit", (browser) => {
        for (const [packId, itemData] of Object.entries(artMapping)) {
            // Apply across all tabs where these items or effects could display
            for (const tabName of ["equipment", "actions"]) {
                const tab = browser.tabs[tabName];
                if (!tab) continue;

                // Loop through and modify the active list
                if (tab.indexData) {
                    for (const entry of tab.indexData) {
                        if (entry.pack === packId) {
                            const match = getArtworkMatch(entry, itemData);
                            if (match?.img) entry.img = match.img;
                        }
                    }
                }

                // Ensure future searches/filters maintain the custom asset mapping
                const originalLoadData = tab.loadData?.bind(tab);
                if (originalLoadData) {
                    tab.loadData = async function() {
                        await originalLoadData();
                        for (const entry of this.indexData) {
                            if (entry.pack === packId) {
                                const match = getArtworkMatch(entry, itemData);
                                if (match?.img) entry.img = match.img;
                            }
                        }
                    };
                }
            }
        }
    });

    console.log("PIWI Art Pack | Custom Module Item Art dynamically bound and visual layers refreshed.");
});